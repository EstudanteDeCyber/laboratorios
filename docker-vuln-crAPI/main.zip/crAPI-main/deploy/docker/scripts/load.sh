docker load -i mailhog.tar
docker load -i gateway-service.tar
docker load -i crapi-identity.tar
docker load -i crapi-community.tar
docker load -i crapi-workshop.tar
docker load -i crapi-web.tar
docker load -i postgres.tar
docker load -i mongo.tar
