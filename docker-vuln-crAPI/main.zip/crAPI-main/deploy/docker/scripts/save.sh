docker save crapi/mailhog:develop -o mailhog.tar
docker save crapi/gateway-service:develop -o gateway-service.tar
docker save crapi/crapi-identity:develop -o crapi-identity.tar
docker save crapi/crapi-community:develop -o crapi-community.tar
docker save crapi/crapi-workshop:develop -o crapi-workshop.tar
docker save crapi/crapi-web:develop -o crapi-web.tar
docker save postgres:14 -o postgres.tar
docker save mongo:4.4 -o mongo.tar
